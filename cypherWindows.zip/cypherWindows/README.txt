Hello! Here is how you use this: I sent you a couple of different files. Create a folder with all of the files in it. Then open up powershell/command prompt whatever you want to call it. Navigate to the folder using the following commands:

cd [folder name] - change directory to the folder mentioned
cd ..            - go back one folder
dir              - list all files and folders in your current directory

Its probably gonna look something like this:

cd OneDrive
cd Downloads
cd Encryption (whatever you name the folder with the files I gave you)
dir (list the files in the folder you are in to make sure that you are in the right place)

Once you found your way to the folder with the program, you can now add whatever message you want to the folder. If you have an encrypted message that you want to decrypt, simply drag and drop it to the folder in your file manager. If you want to create a message to be decrypted, then open up Notepad write your message, and then drag and drop it into the folder with the other files.

THERE ARE ONLY 27 VALID CHARACTERS: capitol A-Z, and _ for spaces. Do not add any numbers, do not add any punctuation, and do not add any lowercase.

Once your message is ready to be encrypted/decrypted, enter the following command into the command line:
cipher.exe [-flag] [path-to-your-file.txt] [key1] [key2]

There are 3 valid flags: -e, -d, -g
These 3 flags represent encrypt, decrypt, and generate key

If you added the file to be encrypted/decrypted to the current folder with all of the other files, you can simply write the name of your file, instead of needing the whole path.

There are 2 keys, and if you don't know how to properly generate one, then use the -g flag to make it. If you use the -g flag, you will still need to pass a file, key1, and key2 as arguments, but it will not affect the file you use, nor will it affect the key generated, so you can pick any valid file, and any numbers as the key.

Here is an example of using the program correctly. Suppose I want to decrypt a file called secretmessage.txt, and my keys are 4 and 584:

cipher.exe -d secretmessage.txt 4 584

REMEMBER that text files have the .txt extension automatically, even if they don't show it, so DON'T FORGET TO ADD IT

if I want to generate a key, then heres how it would look:

cipher.exe -g secretmessage.txt 4 584

REMEMBER that it doesn't matter what the file or keys are, so long as the file is a valid file in the folder.